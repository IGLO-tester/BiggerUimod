package de.biggerui.mixin;

import com.mojang.blaze3d.platform.Window;
import de.biggerui.BiggerUiConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Window.class)
public abstract class WindowMixin {

	/**
	 * Vergrößert den berechneten GUI-Maßstab um den Faktor aus der Config,
	 * begrenzt aber so, dass die Oberfläche noch auf den Bildschirm passt.
	 */
	@Inject(method = "calculateScale", at = @At("RETURN"), cancellable = true)
	private void biggerui$enlargeScale(int guiScale, boolean forceUnicode, CallbackInfoReturnable<Integer> cir) {
		int base = cir.getReturnValue();
		Window self = (Window) (Object) this;

		int scaled = Math.round(base * BiggerUiConfig.factor());
		// GUI soll mindestens 200x150 "GUI-Pixel" groß bleiben
		int cap = Math.min(self.getWidth() / 200, self.getHeight() / 150);

		cir.setReturnValue(Math.max(base, Math.min(scaled, cap)));
	}
}
