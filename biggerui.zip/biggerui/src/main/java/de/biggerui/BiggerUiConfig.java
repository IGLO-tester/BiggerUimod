package de.biggerui;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Liest den Vergrößerungsfaktor aus config/biggerui.properties.
 * Wird beim ersten Zugriff geladen (das Fenster entsteht vor den Mod-Initialisierern).
 */
public final class BiggerUiConfig {
	private static final float DEFAULT_FACTOR = 1.5f;
	private static float factor = -1f;

	private BiggerUiConfig() {
	}

	public static synchronized float factor() {
		if (factor < 0f) {
			factor = load();
		}
		return factor;
	}

	private static float load() {
		Path file = FabricLoader.getInstance().getConfigDir().resolve("biggerui.properties");
		Properties props = new Properties();

		if (Files.exists(file)) {
			try (Reader reader = Files.newBufferedReader(file)) {
				props.load(reader);
				float value = Float.parseFloat(props.getProperty("factor", String.valueOf(DEFAULT_FACTOR)).trim());
				return Math.max(1.0f, Math.min(value, 4.0f));
			} catch (IOException | NumberFormatException e) {
				return DEFAULT_FACTOR;
			}
		}

		props.setProperty("factor", String.valueOf(DEFAULT_FACTOR));
		try (Writer writer = Files.newBufferedWriter(file)) {
			props.store(writer, "BiggerUI: UI-Vergroesserung (1.0 = normal, 1.5 = Standard, bis 4.0)");
		} catch (IOException ignored) {
		}
		return DEFAULT_FACTOR;
	}
}
