# BiggerUI (Fabric, Minecraft 26.2)

Vergrößert die Oberfläche (Hotbar, Inventar, Menüs, Chat) um einen einstellbaren Faktor.

## Einstellung
Nach dem ersten Start liegt `config/biggerui.properties` im Spielordner:

    factor=1.5

1.0 = normal, 1.5 = Standard, 2.0 = doppelt so groß (max. 4.0).
Die Oberfläche wird automatisch begrenzt, damit sie auf den Bildschirm passt.

## Bauen ohne PC (GitHub Actions)
1. Neues Repository auf github.com erstellen und alle Dateien dieses Ordners hochladen
   (inkl. des Ordners `.github`).
2. Tab "Actions" -> Workflow "build" läuft automatisch.
3. Nach ca. 3-5 Minuten: Lauf öffnen -> unter "Artifacts" `biggerui` herunterladen
   -> die `.jar` (ohne `-sources`) liegt im ZIP.

## Installieren (PojavLauncher)
1. In PojavLauncher eine Fabric-Version für 26.2 installieren (Fabric Loader 0.19.3 oder neuer).
2. Die `.jar` in den Ordner `mods` des Profils kopieren.
3. Spiel starten.

## Bauen am PC
    gradle build
(Gradle 9.5.1, Java 25) -> `build/libs/biggerui-1.0.0.jar`
